<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo e($titulo); ?></title>
    <style>
        body {
            font-family: sans-serif;
        }
        .logo {
            width: 150px;
            margin-bottom: 20px;
        }
        .contenedor {
            text-align: center;
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <div class="contenedor">
        <!-- Prueba una imagen con ruta absoluta -->
        <img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="BTS">        
        <!-- Título -->
        <h1><?php echo e($titulo); ?></h1>

        <!-- Prueba un texto simple -->
        <p>Este es un PDF básico generado con DOMPDF.</p>
    </div>
</body>
</html>

<?php /**PATH C:\Users\Lupit\Documents\juntas-flexibles\resources\views\pdf\ejemplo.blade.php ENDPATH**/ ?>