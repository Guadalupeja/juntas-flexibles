

<?php $__env->startSection('title', '¿Cómo seleccionar una junta de expansión? Guía completa y cotización en línea ' . date('Y')); ?>
<?php $__env->startSection('description', 'Aprende a seleccionar la junta de expansión ideal para tu industria. Te explicamos los factores clave, materiales y normas. Cotiza en línea juntas de alta calidad en ' . date('Y') . '.'); ?>

<?php $__env->startSection('structured-data'); ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "Juntas de Expansión Industriales BSH",
  "description": "Fabricamos juntas de expansión personalizadas en hules convencionales y especiales. Ideales para uso industrial. Cotiza sin compromiso con los expertos de BSH.",
  "image": "https://juntasflexibles.com/img/procesadas/Junta-de-expansion-bsh-mexico-large.jpg",
  "brand": {
    "@type": "Brand",
    "name": "BSH"
  },
  "sku": "JUNTA-EXPANSION-INDUSTRIAL",
  "url": "https://juntasflexibles.com/selecciona-juntas-de-expansion/",
  "offers": {
    "@type": "Offer",
    "priceCurrency": "MXN",
    "price": "0",
    "priceValidUntil": "9999-12-31",
    "availability": "https://schema.org/InStock",
    "url": "https://juntasflexibles.com/contacto/"
  }
}
</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>
<div class="bg-white w-full py-10 px-4 md:px-10 max-w-[1240px] mx-auto">
  <div class="flex flex-col md:flex-row items-center gap-10">
    <!-- Imagen -->
    <div class="w-[100%]">
      <div class="w-[100%]">
        <picture>
          <!-- WebP -->
          <source 
            type="image/webp" 
            srcset="
              <?php echo e(asset('/img/procesadas/1955065473_industrial-expansion-joints-_xl-beta-v2-2-2-small.webp')); ?> 480w,
              <?php echo e(asset('/img/procesadas/1955065473_industrial-expansion-joints-_xl-beta-v2-2-2-medium.webp')); ?> 800w,
              <?php echo e(asset('/img/procesadas/1955065473_industrial-expansion-joints-_xl-beta-v2-2-2-large.webp')); ?> 1200w"
            sizes="(max-width: 480px) 480px, (max-width: 800px) 800px, 1200px">
      
          <!-- JPG -->
          <source 
            type="image/jpeg" 
            srcset="
              <?php echo e(asset('/img/procesadas/1955065473_industrial-expansion-joints-_xl-beta-v2-2-2-small.jpg')); ?> 480w,
              <?php echo e(asset('/img/procesadas/1955065473_industrial-expansion-joints-_xl-beta-v2-2-2-medium.jpg')); ?> 800w,
              <?php echo e(asset('/img/procesadas/1955065473_industrial-expansion-joints-_xl-beta-v2-2-2-large.jpg')); ?> 1200w"
            sizes="(max-width: 480px) 480px, (max-width: 800px) 800px, 1200px">
      
          <!-- Fallback -->
          <img 
            src="<?php echo e(asset('/img/procesadas/1955065473_industrial-expansion-joints-_xl-beta-v2-2-2-large.jpg')); ?>" 
            alt="Imagen seleccion adecuada de juntas flexibles"
            class="w-full h-auto rounded-xl shadow-md"
            loading="lazy"
          />
        </picture>
      </div>
      
    </div>

    <!-- Texto -->
    <div class="w-full md:w-1/2">
      <h1 class="text-[2rem] font-roboto font-semibold text-[#164ec9] mb-4">
        ¿Cómo seleccionar adecuadamente una junta de expansión?
      </h1>

      <h2 class="text-xl font-bold text-[#164ec9] mb-4">
        Seleccionar adecuadamente tus juntas de expansión
      </h2>

      <p class="mb-4">Requieres considerar varios factores clave. A continuación, te presento algunos pasos para ayudarte en este proceso:</p>

      <ul class="list-disc list-inside space-y-3 text-base leading-relaxed">
        <li>
          <strong>Identifica el tipo de aplicación:</strong> Evalúa el entorno de uso: temperatura, presión, corrosión, etc.
        </li>
        <li>
          <strong>Estudia los materiales:</strong> Compatibilidad con fluidos, resistencia a la corrosión y temperaturas extremas.
        </li>
        <li>
          <strong>Evalúa tamaño y capacidad de movimiento:</strong> Asegura que la junta se adapta a los movimientos térmicos o vibraciones.
        </li>
        <li>
          <strong>Normas y estándares:</strong> Asegura el cumplimiento con regulaciones específicas de tu industria.
        </li>
        <li>
          <strong>Consulta a expertos:</strong> Nosotros te asesoramos sin costo. 
        </li>
      </ul>

      <p class="mt-6">
        Visita nuestro <a href="https://juntasflexibles.com/" class="underline text-[#164ec9] hover:text-[#0e358a] transition">sitio web</a> o utiliza nuestra 
        <a href="https://juntasflexibles.com/selecciona-juntas-de-expansion/" class="underline text-[#164ec9] hover:text-[#0e358a] transition">herramienta de selección</a>.
      </p>
    </div>
  </div>
</div>

<!-- Segunda sección con imagen de fondo y formulario -->
<section class="w-full bg-cover bg-center bg-no-repeat text-white font-roboto py-16 px-4"
  style="
    background-image: url('/img/procesadas/bombas-industriales-large.jpg');
    background-image: -webkit-image-set(
      url('/img/procesadas/bombas-industriales-large.webp') type('image/webp'),
      url('/img/procesadas/bombas-industriales-large.jpg') type('image/jpeg')
    );
    background-image: image-set(
      url('/img/procesadas/bombas-industriales-large.webp') type('image/webp'),
      url('/img/procesadas/bombas-industriales-large.jpg') type('image/jpeg')
    );
  "
>
  <div class="max-w-4xl mx-auto bg-black/60 p-6 rounded-xl">
    <h2 class="text-2xl md:text-3xl font-bold mb-4">
      ¿Necesitas más información sobre las juntas de expansión?
    </h2>
    <p class="mb-6">
      Por favor llena el siguiente formulario y en breve un experto se comunicará contigo:
    </p>

    <!-- Formulario HubSpot -->
    <div>
        <!-- Carga diferida de HubSpot -->
        <div id="hubspot-form"></div>   
        
        <link rel="preconnect" href="https://js.hsforms.net">
        <link rel="dns-prefetch" href="https://js.hsforms.net">
        
        <script>
          document.addEventListener('DOMContentLoaded', () => {
            const target = document.getElementById('hubspot-form');
        
            function loadHubSpot() {
              if (window.hsFormLoaded) return;         // evita doble carga
              window.hsFormLoaded = true;
        
              const s   = document.createElement('script');
              s.src     = 'https://js.hsforms.net/forms/v2.js'; // 30-40 % más ligero que shell.js
              s.async   = true;
              s.onload  = () => {
                if (window.hbspt) {
                  hbspt.forms.create({
                    region   : 'na1',
                    portalId : '7547674',
                    formId   : 'e391047b-0ba7-411a-85bc-4c528141e149',
                    target   : '#hubspot-form'
                  });
                }
              };
              document.body.appendChild(s);
            }
        
            /* ① Carga cuando la sección CONTACTO entra a viewport (≈ 200 px antes) */
            if ('IntersectionObserver' in window) {
              const io = new IntersectionObserver((entries, observer) => {
                if (entries[0].isIntersecting) {
                  loadHubSpot();
                  observer.disconnect();
                }
              }, { rootMargin: '0px 0px 200px 0px' });
              io.observe(target);
            } else {
              /* ② Respaldo: si el navegador no soporta IO, espera 5 s tras load */
              window.addEventListener('load', () => setTimeout(loadHubSpot, 5000));
            }
          });
        </script>
    </div>
  </div>
</section>

<!-- Puntuación -->
<div class="flex flex-col items-center my-10">
  <div class="mb-2 text-lg">¡Haz clic para puntuar esta página!</div>
  <div id="star-rating" class="flex space-x-2">
    <?php for($i = 1; $i <= 5; $i++): ?>
      <img src="/img/star_2.svg" data-rating="<?php echo e($i); ?>" class="star cursor-pointer w-8 h-8" alt="Estrella <?php echo e($i); ?>">
    <?php endfor; ?>
  </div>
  <div class="mt-2 text-sm">
    (Votos: <span id="votes-count">0</span> Promedio: <span id="average-rating">0</span>)
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lupit\Documents\juntas-flexibles\resources\views\seleccionar-adecuadamente-una-junta.blade.php ENDPATH**/ ?>