<?php
phpinfo();
