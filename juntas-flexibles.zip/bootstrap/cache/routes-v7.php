<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HPAl3fIY5Ls952mV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'inicio',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/selecciona-juntas-de-expansion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'selecciona_juntas',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/junta-flexible-bsh-1110' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'junta_flexible_bsh_1110',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/junta-flexible-bsh-111c' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'junta_flexible_bsh_111c',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/junta-flexible-bsh-111e' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'junta_flexible_bsh_111e',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/junta-flexible-bsh-1120' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'junta_flexible_bsh_1120',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/junta-flexible-bsh-1130' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'junta_flexible_bsh_1130',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/junta-flexible-bsh-2210' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'junta_flexible_bsh_2210',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/acerca' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'acerca',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/contact' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'contact',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/estilos-juntas-de-expansion-bsh' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'estilos',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/gracias' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'gracias',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/aviso-de-privacidad' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'aviso-de-privacidad',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/2022/11/28/como-seleccionar-adecuadamente-una-junta-de-expansion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'seleccionar-adecuadamente-una-junta',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/preguntas-frecuentes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'preguntas-frecuentes',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/2023/06/29/de-que-materiales-estan-hechas-las-juntas-de-expansion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'de-que-materiales',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/2023/07/26/que-es-una-junta-de-expansion-bridada' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'que-es-una-junta',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/2023/09/08/guia-de-juntas-de-expansion-medidas-comunes-y-su-importancia' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'guia-de-juntas',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/filtros-seleccion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filtros.seleccion',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/seccion-cuatro' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filtros.segundaEtapa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cotizacion-generada' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cotizacion.generada',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pdf-basico' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rm1JtMCVpyKf83hG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rate-page' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rate.page',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/get\\-rating/([^/]++)(*:28)|/storage/(.*)(*:48))/?$}sDu',
    ),
    3 => 
    array (
      28 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'get.rating',
          ),
          1 => 
          array (
            0 => 'page_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      48 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::HPAl3fIY5Ls952mV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:846:"function () {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'C:\\\\Users\\\\Lupit\\\\Documents\\\\juntas-flexibles\\\\vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Foundation\\\\Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $exception ? 500 : 200);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"00000000000004c90000000000000000";}}',
        'as' => 'generated::HPAl3fIY5Ls952mV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'inicio' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@inicio',
        'controller' => 'App\\Http\\Controllers\\PaginasController@inicio',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'inicio',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'selecciona_juntas' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'selecciona-juntas-de-expansion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@selecciona_juntas',
        'controller' => 'App\\Http\\Controllers\\PaginasController@selecciona_juntas',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'selecciona_juntas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'junta_flexible_bsh_1110' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'junta-flexible-bsh-1110',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@junta_flexible_bsh_1110',
        'controller' => 'App\\Http\\Controllers\\PaginasController@junta_flexible_bsh_1110',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'junta_flexible_bsh_1110',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'junta_flexible_bsh_111c' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'junta-flexible-bsh-111c',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@junta_flexible_bsh_111c',
        'controller' => 'App\\Http\\Controllers\\PaginasController@junta_flexible_bsh_111c',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'junta_flexible_bsh_111c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'junta_flexible_bsh_111e' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'junta-flexible-bsh-111e',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@junta_flexible_bsh_111e',
        'controller' => 'App\\Http\\Controllers\\PaginasController@junta_flexible_bsh_111e',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'junta_flexible_bsh_111e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'junta_flexible_bsh_1120' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'junta-flexible-bsh-1120',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@junta_flexible_bsh_1120',
        'controller' => 'App\\Http\\Controllers\\PaginasController@junta_flexible_bsh_1120',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'junta_flexible_bsh_1120',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'junta_flexible_bsh_1130' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'junta-flexible-bsh-1130',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@junta_flexible_bsh_1130',
        'controller' => 'App\\Http\\Controllers\\PaginasController@junta_flexible_bsh_1130',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'junta_flexible_bsh_1130',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'junta_flexible_bsh_2210' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'junta-flexible-bsh-2210',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@junta_flexible_bsh_2210',
        'controller' => 'App\\Http\\Controllers\\PaginasController@junta_flexible_bsh_2210',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'junta_flexible_bsh_2210',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'acerca' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'acerca',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@acerca',
        'controller' => 'App\\Http\\Controllers\\PaginasController@acerca',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'acerca',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'contact' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'contact',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@contact',
        'controller' => 'App\\Http\\Controllers\\PaginasController@contact',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'contact',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'estilos' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'estilos-juntas-de-expansion-bsh',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@estilos',
        'controller' => 'App\\Http\\Controllers\\PaginasController@estilos',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'estilos',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'gracias' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'gracias',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@gracias',
        'controller' => 'App\\Http\\Controllers\\PaginasController@gracias',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'gracias',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'aviso-de-privacidad' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'aviso-de-privacidad',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@aviso_de_privacidad',
        'controller' => 'App\\Http\\Controllers\\PaginasController@aviso_de_privacidad',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'aviso-de-privacidad',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'seleccionar-adecuadamente-una-junta' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '2022/11/28/como-seleccionar-adecuadamente-una-junta-de-expansion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@seleccionar_adecuadamente_una_junta',
        'controller' => 'App\\Http\\Controllers\\PaginasController@seleccionar_adecuadamente_una_junta',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'seleccionar-adecuadamente-una-junta',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'preguntas-frecuentes' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'preguntas-frecuentes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@preguntas_frecuentes',
        'controller' => 'App\\Http\\Controllers\\PaginasController@preguntas_frecuentes',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'preguntas-frecuentes',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'de-que-materiales' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '2023/06/29/de-que-materiales-estan-hechas-las-juntas-de-expansion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@de_que_materiales',
        'controller' => 'App\\Http\\Controllers\\PaginasController@de_que_materiales',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'de-que-materiales',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'que-es-una-junta' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '2023/07/26/que-es-una-junta-de-expansion-bridada',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@que_es_una_junta',
        'controller' => 'App\\Http\\Controllers\\PaginasController@que_es_una_junta',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'que-es-una-junta',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'guia-de-juntas' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '2023/09/08/guia-de-juntas-de-expansion-medidas-comunes-y-su-importancia',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PaginasController@guia_de_juntas',
        'controller' => 'App\\Http\\Controllers\\PaginasController@guia_de_juntas',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'guia-de-juntas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filtros.seleccion' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'filtros-seleccion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\FiltrosController@filtrosSeleccion',
        'controller' => 'App\\Http\\Controllers\\FiltrosController@filtrosSeleccion',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'filtros.seleccion',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filtros.segundaEtapa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'seccion-cuatro',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\FiltrosController@filtrosSeleccionSegundaEtapa',
        'controller' => 'App\\Http\\Controllers\\FiltrosController@filtrosSeleccionSegundaEtapa',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'filtros.segundaEtapa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cotizacion.generada' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'cotizacion-generada',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\CotizacionController@generarCotizacion',
        'controller' => 'App\\Http\\Controllers\\CotizacionController@generarCotizacion',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cotizacion.generada',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rm1JtMCVpyKf83hG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pdf-basico',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\PdfController@generarPDF',
        'controller' => 'App\\Http\\Controllers\\PdfController@generarPDF',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rm1JtMCVpyKf83hG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rate.page' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'rate-page',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\RatingController@store',
        'controller' => 'App\\Http\\Controllers\\RatingController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'rate.page',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'get.rating' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'get-rating/{page_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Spatie\\ResponseCache\\Middlewares\\CacheResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\RatingController@show',
        'controller' => 'App\\Http\\Controllers\\RatingController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'get.rating',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:4:{s:6:"driver";s:5:"local";s:4:"root";s:61:"C:\\Users\\Lupit\\Documents\\juntas-flexibles\\storage\\app/private";s:5:"serve";b:1;s:5:"throw";b:0;}s:12:"isProduction";b:0;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000004ce0000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
